# Mi IPTV Efecto — proyecto Android v1.3

## Funciones
- Interfaz azul oscuro/celeste y marca MI IPTV EFECTO.
- Inicio, TV en vivo, Películas, Series, Favoritos y Configuración.
- Carga de listas M3U/M3U8 por URL o archivo.
- Xtream Codes para canales en vivo, películas y series/episodios.
- Favoritos y datos de acceso guardados cifrados en el dispositivo.
- Administrador de varias listas M3U/Xtream: guardar, activar o eliminar fuentes.
- Respaldo automático: ante un error de reproducción, intenta buscar el mismo canal en las otras listas guardadas.
- Interruptor para activar/desactivar el respaldo automático.

## Cómo usar el respaldo
1. Cargá una lista o conectá una cuenta desde Configuración.
2. En “Listas de respaldo”, escribí un nombre y tocá “Guardar lista actual como respaldo”.
3. Repetí con otras listas autorizadas.
4. Podés tocar “Usar” para cambiar manualmente o dejar activado “Cambio automático”.

El cambio automático busca el mismo nombre de canal en las otras fuentes. Si el canal no existe allí, no puede reemplazarlo. Un error de red o del proveedor también puede ser temporal; por eso no se garantiza continuidad perfecta.

## Compilar
Abrir el proyecto en Android Studio, sincronizar Gradle y elegir Build > Build Bundle(s) / APK(s) > Build APK(s). El ZIP es código fuente, no un APK compilado.

## Pendiente de pruebas
Debe compilarse y probarse con listas autorizadas reales. EPG, carátulas, adaptación completa del control remoto Android TV y pruebas de estabilidad siguen pendientes.
