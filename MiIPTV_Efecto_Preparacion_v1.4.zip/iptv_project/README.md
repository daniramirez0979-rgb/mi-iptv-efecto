# Mi IPTV Efecto — proyecto Android (preparación v1.4)

Proyecto Android de código fuente para compilar una APK de prueba.

## Estado real
- Interfaz azul oscuro/celeste y marca MI IPTV EFECTO.
- Secciones: Inicio, TV en vivo, Películas, Series, Favoritos y Configuración.
- Reproductor Media3/ExoPlayer.
- Carga manual de listas M3U/M3U8 y cuentas Xtream.
- Perfiles de listas locales y respaldo/failover local.
- **Todavía no está integrado el inicio de sesión de clientes con Supabase.**
- **Todavía no consulta el estado habilitado/vencimiento del cliente ni descarga el catálogo remoto.**
- Esta carpeta contiene código fuente, no una APK ya compilada ni probada.

## Compilar en la nube con GitHub Actions
1. Subir el contenido de este proyecto a un repositorio GitHub propio.
2. Abrir la pestaña Actions y ejecutar `Build Mi IPTV Efecto APK` (o hacer push a `main`).
3. Cuando termine correctamente, descargar el artefacto `Mi-IPTV-Efecto-debug` desde la ejecución.
4. Dentro estará `app-debug.apk`, que es una APK de prueba.

El flujo compila con JDK 17 y Android SDK en GitHub Actions. La APK debug no es una versión firmada para publicación.

## Próxima integración pendiente
La app debe autenticarse con Supabase Auth, consultar un endpoint protegido que valide `iptv_clients.enabled` y `expires_at`, y recibir únicamente las listas habilitadas. No incluir nunca `service_role` en la app. Las URLs M3U/Xtream que el reproductor necesite pueden ser recuperadas por usuarios técnicamente avanzados, aunque se proteja el acceso mediante login.

## Pruebas pendientes
La compilación real, inicio de sesión, validación de cliente, reproducción de listas autorizadas, TV Box/control remoto, EPG y estabilidad deben probarse antes de distribuir.
